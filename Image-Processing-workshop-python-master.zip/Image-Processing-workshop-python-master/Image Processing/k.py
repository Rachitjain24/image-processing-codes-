import cv2
import numpy as np


image = cv2.imread('test1.jpg')

print(type(image))
