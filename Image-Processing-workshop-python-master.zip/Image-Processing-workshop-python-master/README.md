# Image-Processing-workshop-python
For the workshop held in ADGITM on 11th-12th February, 2020
This repository is only meant for the students who attended the workshop to get a reference to the codes for practice.

## You can find the codes in the folder

The Image processing folder contains the codes we used during the workshop. 
For easy installation, I recommend that you clone/download the whole repository as it is and check paths of images.

## Projects

Please download more haarcascades by googling them, there are plenty of haarcascades available on the internet.

## Further Reading 

You can read more about Image Processing at https://opencv-python-tutroals.readthedocs.io/en/latest/
<>
You can read more about Python at https://www.w3schools.com/Python/default.asp

